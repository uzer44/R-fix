//
//  AppDelegate.swift
//  interviewWebcluse
//
//  Created by Uzer kagdi on 03/07/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import CoreData
var AppInstance: AppDelegate!
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    var _navigation : UINavigationController!
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
         AppInstance = self
        sleep(2)
        if   let token =  UserDefaults.standard.string(forKey: "request_token")
        {
            print(token)
            let islogin = UserDefaults.standard.bool(forKey: "login")
            if  islogin == true
            {
                self.goToHomeScreenPage(transition: true)
            }else{
                self.goToLoginScreenPage(transition: true)
            }
        }else
        {
             
            
            postRequest(api_key:"823efcfb80a0302260db02cad43613af") { (result, error) in
                if let result = result {
                    print("success: \(result)")
                    UserDefaults.standard.set(result["request_token"] as! String, forKey: "request_token")
                    //["expires_at": 2020-07-18 15:18:09 UTC, "request_token": //f12197424dc5203fa4bb08d1aac2f4856ea1da43, "success": 1]

                } else if let error = error {
                    print("error: \(error.localizedDescription)")
                }
                
            }
        }
        return true
    }
    
    func goToHomeScreenPage(transition : Bool)
    {
        
        let storyboard = UIStoryboard.init(name: "Authentication", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        _navigation = UINavigationController(rootViewController: viewController)
        
        _navigation.setNavigationBarHidden(false, animated: true)
        window!.rootViewController = _navigation
        let transitionOption = transition ? UIView.AnimationOptions.transitionFlipFromLeft : UIView.AnimationOptions.transitionFlipFromLeft
        gotoViewController(viewController: _navigation, transition: transitionOption)
    }
    
    
    func goToLoginScreenPage(transition : Bool)
    {
        
        let storyboard = UIStoryboard.init(name: "Authentication", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        _navigation = UINavigationController(rootViewController: viewController)
        
        _navigation.setNavigationBarHidden(true, animated: true)
        window!.rootViewController = _navigation
        let transitionOption = transition ? UIView.AnimationOptions.transitionFlipFromLeft : UIView.AnimationOptions.transitionFlipFromLeft
        gotoViewController(viewController: _navigation, transition: transitionOption)
    }
    
    
    
    func gotoViewController(viewController: UIViewController, transition: UIView.AnimationOptions)
    {
        
        if transition != UIView.AnimationOptions.showHideTransitionViews
        {
            //self.window = UIWindow(frame: UIScreen.main.bounds)
            UIView.transition(with: self.window!, duration: 0.5, options: transition, animations: { () -> Void in
                self.window!.rootViewController = viewController
            }, completion: { (finished: Bool) -> Void in
                
            })
        }
        else
        {
            window!.rootViewController = viewController
        }
    }
    
    
    //------------------------------------------
    //MARK: - API Methods -
    
    func postRequest(api_key: String,completion: @escaping ([String: Any]?, Error?) -> Void) {
        
        //declare parameter as a dictionary which contains string as key and value combination.
        // let parameters = ["api_key": api_key]
        
        //create the url with NSURL
        let url = URL(string: "https://api.themoviedb.org/3/authentication/token/new?api_key=823efcfb80a0302260db02cad43613af")!
        
        //create the session object
        let session = URLSession.shared
        
        //now create the Request object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "GET" //set http method as POST
        
        
        //           do {
        //               request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to data object and set it as request body
        //           } catch let error {
        //               print(error.localizedDescription)
        //               completion(nil, error)
        //           }
        
        //HTTP Headers
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard error == nil else {
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                return
            }
            
            do {
                //create json object from data
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                    completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                    return
                }
                print(json)
                completion(json, nil)
            } catch let error {
                print(error.localizedDescription)
                completion(nil, error)
            }
        })
        
        task.resume()
    }
    
    
    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "interviewWebcluse")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
}

