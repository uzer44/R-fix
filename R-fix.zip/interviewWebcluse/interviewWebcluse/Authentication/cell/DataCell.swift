//
//  DataCell.swift
//  interviewWebcluse
//
//  Created by Uzer kagdi on 03/07/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import Kingfisher
class DataCell: UITableViewCell {
    
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet var collCategory: UICollectionView!
    var displayDataCollection = [Frontpage]()
    var viewcontrollerpush = UIViewController()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collCategory.dataSource = self
        collCategory.delegate = self
        print(displayDataCollection.count)
        //collCategory.frame.size.width = self.contentView.frame.size.width
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func loadCollectionWithArray(arrayData :  [Frontpage])
    {
        displayDataCollection = arrayData
        
        self.collCategory.reloadData()
    }
    
}
extension DataCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        collCategory.frame.size.width = self.contentView.frame.size.width
        return self.displayDataCollection.count
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell : CategoryCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
        if self.displayDataCollection.count > 0
        {
            
            cell.lblTitle.text = self.displayDataCollection[indexPath.row].title
            cell.lblReleaseDate.text = self.displayDataCollection[indexPath.row].release_date
            cell.imgMovie.kf.indicatorType = .activity
            let url = "http://image.tmdb.org/t/p/w185/" + self.displayDataCollection[indexPath.row].poster_path
            
            cell.imgMovie.kf.setImage(with: URL(string: url), placeholder:UIImage(named: "war-b717"))
            cell.lblRating.text = "\(self.displayDataCollection[indexPath.row].vote_average)/10"
        }
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let resultVC = Utilities.viewController(name: "DetailVC", onStoryboard: "Authentication") as! DetailVC
        resultVC.movieId = self.displayDataCollection[indexPath.row].id.description
        self.viewcontrollerpush.navigationController?.pushViewController(resultVC, animated: true)
        
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 120, height: 190)
    }
}



