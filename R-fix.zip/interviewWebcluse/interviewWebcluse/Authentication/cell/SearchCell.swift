//
//  SearchCell.swift
//  interviewWebcluse
//
//  Created by HOLOTEQ-MAC-PC-3 on 7/20/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet weak var lblRelease: UILabel!
    @IBOutlet weak var lblMovieName: UILabel!
    @IBOutlet weak var imgMovie: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
