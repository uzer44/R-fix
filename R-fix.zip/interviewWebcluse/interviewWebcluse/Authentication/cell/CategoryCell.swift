//
//  CategoryCell.swift
//  interviewWebcluse
//
//  Created by Uzer kagdi on 18/07/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit

class CategoryCell: UICollectionViewCell {
    
    
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblReleaseDate: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgMovie: UIImageView!
}
