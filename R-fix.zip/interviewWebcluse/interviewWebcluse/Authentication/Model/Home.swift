//
//  Home.swift
//  Mobilizer
//
//  Created by MacMini12 on 30/01/19.
//  Copyright © 2019 MacMini12. All rights reserved.
//

import Foundation
import SwiftyJSON
class baseFrontpage
{
    
    var frontpage_list = [Frontpage]()
    
    //var response_langData = [AppData]()
    
    func addItem(data: JSON)
    {
        
        for (_,obj) in data
        {
            let appObj = Frontpage()
            appObj.update(data: obj as JSON)
            frontpage_list.append(appObj)
            
        }
        
    }
    
}

class Frontpage
{
    
    var popularity = 0.0
      var vote_count = 0
      var video =  false
       var poster_path = ""
       var id = 0
       var adult =  false
      var backdrop_path = ""
       var original_language = ""
        var original_title = ""
    var genre_ids : [Int] = []
//    "genre_ids": [
//          12,
//          14,
//          878,
//          10751
//        ],
       var title = ""
       var vote_average = 0.0
        var overview = ""
        var release_date = ""
    
    
    var name = ""
    var locationId = ""
    var contentId = ""
    // var banner = ""
    var sort_key = ""
    var icon = ""
    var category = ""
    
 
    
    func update(data: JSON)
    {
        vote_average = data["vote_average"].double ?? 0.0
        backdrop_path = data["backdrop_path"].string ?? ""
        original_language = data["original_language"].string ?? ""
        original_title = data["original_title"].string ?? ""
        title = data["title"].string ?? ""
        overview = data["overview"].string ?? ""
        release_date = data["release_date"].string ?? ""
        poster_path = data["poster_path"].string ?? ""
        popularity = data["popularity"].double ?? 0.0
          vote_count = data["vote_count"].int ?? 0
        id = data["id"].int ?? 0
      
        
        
       
            for(_,childrenDetails) in data["genre_ids"]
            {
                
//                let childrenObj = genresIds()
//                childrenObj.update(data: childrenDetails as JSON)
                genre_ids.append(childrenDetails.int!)
            }
        
    }
    
    
}



