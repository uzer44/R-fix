//
//  CastModel.swift
//  interviewWebcluse
//
//  Created by HOLOTEQ-MAC-PC-3 on 7/20/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import Foundation
import SwiftyJSON
class CastModel {
    var cast_id = 0
   var character = ""
    var credit_id = ""
   var gender = 0
    var id = 0
    var name = ""
   var order = 0
    var profile_path = ""
    var title = ""
    var vote_average = 0
   var poster_path = ""
    
    func Populate(dictionary:JSON)
    {
        gender = dictionary["gender"].intValue
         id = dictionary["id"].intValue
         vote_average = dictionary["vote_average"].intValue
        cast_id = dictionary["cast_id"].intValue
        character = dictionary["character"].stringValue
        credit_id = dictionary["credit_id"].stringValue
        name = dictionary["name"].stringValue
        profile_path = dictionary["profile_path"].stringValue
        poster_path = dictionary["poster_path"].stringValue
        title = dictionary["title"].stringValue
        order = dictionary["order"].intValue
        
        
        
       
    }
    class func PopulateArray(array:[JSON]) -> [CastModel]
    {
        var result:[CastModel] = []
        for item in array
        {
            let newItem = CastModel()
            newItem.Populate(dictionary: item)
            result.append(newItem)
        }
        return result
    }
}
