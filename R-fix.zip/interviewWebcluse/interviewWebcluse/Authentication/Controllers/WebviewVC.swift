//
//  WebviewVC.swift
//  interviewWebcluse
//
//  Created by HOLOTEQ-MAC-PC-3 on 7/22/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import WebKit
class WebviewVC: UIViewController,WKNavigationDelegate {

    var webView: WKWebView!
    var Homeurl = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        webView = WKWebView()
         webView.navigationDelegate = self
         
        let url = URL(string: Homeurl)!
        webView.load(URLRequest(url: url))
        webView.allowsBackForwardNavigationGestures = true
        view = webView
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
