//
//  DetailVC.swift
//  interviewWebcluse
//
//  Created by HOLOTEQ-MAC-PC-3 on 7/20/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import SwiftyJSON
import Cosmos
class DetailVC: UIViewController {
    var movieId = ""
    var objMovieDetail = DetailModel()
    var ObjCast = [CastModel]()
    var ObjRecommendation = [CastModel]()
    var rating = 0.0
    @IBOutlet weak var imgPoster: UIImageView!
    
    @IBOutlet weak var viewRating: UIView!
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblGenres: UILabel!
    @IBOutlet weak var lblrating: UILabel!
    @IBOutlet weak var lblReleaseDate: UILabel!
    @IBOutlet weak var lblMoviename: UILabel!
    
    @IBOutlet weak var viewCosmos: CosmosView!
    @IBOutlet weak var collRecommendation: UICollectionView!
    @IBOutlet weak var collCast: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: getDetail Data
        self.getData(_url: "https://api.themoviedb.org/3/movie/\(movieId)?api_key=823efcfb80a0302260db02cad43613af&language=en-US") { (response, err) in
            if let result = response
            {
                print("success: \(result)")
                let jsonObj = JSON(result)
                
                let detailObj = DetailModel()
                detailObj.Populate(dictionary: jsonObj)
                self.objMovieDetail = detailObj
                DispatchQueue.main.async {
                    self.setData()
                }
                
                
            }else if let error = err
            {
                print("error: \(error.localizedDescription)")
            }
        }
        //MARK: getCast Data
        self.getData(_url: "https://api.themoviedb.org/3/movie/\(movieId)/credits?api_key=823efcfb80a0302260db02cad43613af") { (response, err) in
            if let result = response
            {
                print("success: \(result)")
                let jsonObj = JSON(result)
                
                let castdata =  CastModel.PopulateArray(array: jsonObj["crew"].arrayValue)
                self.ObjCast.append(contentsOf: castdata)
                
                DispatchQueue.main.async {
                    self.collCast.reloadData()
                }
                
                
            }else if let error = err
            {
                print("error: \(error.localizedDescription)")
            }
        }
        //MARK: getRecommendationData
        self.getData(_url: "https://api.themoviedb.org/3/movie/\(movieId)/recommendations?api_key=823efcfb80a0302260db02cad43613af&language=en-US&page=1") { (response, err) in
            if let result = response
            {
                let jsonObj = JSON(result)
                
                let castdata =  CastModel.PopulateArray(array: jsonObj["results"].arrayValue)
                self.ObjRecommendation.append(contentsOf: castdata)
                DispatchQueue.main.async {
                    self.collRecommendation.reloadData()
                }
                
                
            }else if let error = err
            {
                print("error: \(error.localizedDescription)")
            }
        }
        
        //MARK: for rating view
        viewCosmos.rating = 0
        
        viewCosmos.didFinishTouchingCosmos = {
            rating in
            print(rating)
            self.rating = rating
            
        }
       viewCosmos.didTouchCosmos = {
        rating in
        switch rating {
        case 1.0:
            self.lblRating.text = "Awful"
            
            case 2.0:
            self.lblRating.text = "Meh"
            case 3.0:
            self.lblRating.text = "Nice"
            case 4.0:
            self.lblRating.text = "Great"
            case 5.0:
                       self.lblRating.text = "Epic"
        default:
            break
        }
        
        }
        //MARK: tap for rmeoving viewRating
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        viewRating.addGestureRecognizer(tap)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.viewRating.isHidden = true
    }
    @IBAction func btnRateClicked(_ sender: Any)
    {
        self.viewRating.isHidden = false
    }
    
    
    
    @IBAction func btnSendRatingClicked(_ sender: Any)
    {
        if rating != 0.0
        {
            SendRating(value: rating.description) { (response, err) in
            if let result = response
            {
               
                if  let code =  result["status_code"]
                                   {
                                       DispatchQueue.main.async {
                                        Utilities.displayAlert(msg: result["status_message"] as! String, isfromlogin: true,navigation:self.navigationController!)
                                       }
                                   }
                
            }else if let error = err
            {
                print("error: \(error.localizedDescription)")
            }
        }
        }
    }
    
    
    @IBAction func btnHomeClicked(_ sender: Any)
    {
        
        let resultVC = Utilities.viewController(name: "WebviewVC", onStoryboard: "Authentication") as! WebviewVC
        resultVC.Homeurl = self.objMovieDetail.homepage ?? ""
        self.navigationController!.pushViewController(resultVC, animated: true)
    }
    
    func setData()
    {
        self.lblGenres.text = self.objMovieDetail._genres[0].name
        self.lblMoviename.text = self.objMovieDetail.title ?? ""
        self.lblrating.text = (self.objMovieDetail.runtime?.description)! + " mins"
        self.lblReleaseDate.text =  self.objMovieDetail.release_date ?? ""
        self.imgPoster.kf.indicatorType = .activity
        let url = "http://image.tmdb.org/t/p/w780/" + (self.objMovieDetail.poster_path ?? "")
        
        if self.objMovieDetail.homepage == ""
        {
            self.navigationItem.rightBarButtonItem?.isEnabled = false
        }
        
        self.imgPoster.kf.setImage(with: URL(string: url), placeholder:UIImage(named: "war-b717"))
    }
    
    //MARK: -  Api method
    
    func SendRating(value: String,completion: @escaping ([String: Any]?, Error?) -> Void) {
        
          //declare parameter as a dictionary which contains string as key and value combination.
          let parameters = ["value": value]
          
          //create the url with NSURL
          let url = URL(string: "https://api.themoviedb.org/3/movie/\(movieId)/rating?api_key=823efcfb80a0302260db02cad43613af")!
          
          //create the session object
          let session = URLSession.shared
          
          //now create the Request object using the url object
          var request = URLRequest(url: url)
          request.httpMethod = "POST" //set http method as POST
          
          do {
              request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to data object and set it as request body
          } catch let error {
              print(error.localizedDescription)
              completion(nil, error)
          }
          
          //HTTP Headers
          request.addValue("application/json", forHTTPHeaderField: "Content-Type")
          request.addValue("application/json", forHTTPHeaderField: "Accept")
          
          //create dataTask using the session object to send data to the server
          let task = session.dataTask(with: request, completionHandler: { data, response, error in
              
              guard error == nil else {
                  completion(nil, error)
                  return
              }
              
              guard let data = data else {
                  completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                  return
              }
              
              do {
                  //create json object from data
                  guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                      completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                      return
                  }
                  print(json)
                  completion(json, nil)
              } catch let error {
                  print(error.localizedDescription)
                  completion(nil, error)
              }
          })
          
          task.resume()
      }
    
    func getData(_url : String,completion: @escaping ([String: Any]?, Error?) -> Void) {
        
        //declare parameter as a dictionary which contains string as key and value combination.
        // let parameters = ["api_key": api_key]
        
        //create the url with NSURL
        
        let url = URL(string:_url)!
        
        //create the session object
        let session = URLSession.shared
        
        //now create the Request object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "GET" //set http method as POST
        
        
        //           do {
        //               request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to data object and set it as request body
        //           } catch let error {
        //               print(error.localizedDescription)
        //               completion(nil, error)
        //           }
        
        //HTTP Headers
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard error == nil else {
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                return
            }
            
            do {
                //create json object from data
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                    completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                    return
                }
                print(json)
                completion(json, nil)
            } catch let error {
                print(error.localizedDescription)
                completion(nil, error)
            }
        })
        
        task.resume()
    }
    //MARK: -  Api method
    
}
extension DetailVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == self.collCast
        {
            return self.ObjCast.count
        }else
        {
            return self.ObjRecommendation.count
        }
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell : CategoryCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
        if collectionView == self.collCast
        {
            if self.ObjCast.count > 0
            {
                cell.imgMovie.kf.indicatorType = .activity
                let url = "http://image.tmdb.org/t/p/w185/" + self.ObjCast[indexPath.row].profile_path
                cell.imgMovie.kf.setImage(with: URL(string: url), placeholder:UIImage(named: "war-b717"))
                cell.lblTitle.text = self.ObjCast[indexPath.row].name
            }
            
        }else
        {
            if self.ObjRecommendation.count > 0
            {
                cell.imgMovie.kf.indicatorType = .activity
                let url = "http://image.tmdb.org/t/p/w185/" + self.ObjRecommendation[indexPath.row].poster_path
                cell.imgMovie.kf.setImage(with: URL(string: url), placeholder:UIImage(named: "war-b717"))
                cell.lblTitle.text = self.ObjRecommendation[indexPath.row].title
            }
        }
        
        return cell
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if collectionView == self.collRecommendation
        {
            let resultVC = Utilities.viewController(name: "DetailVC", onStoryboard: "Authentication") as! DetailVC
            resultVC.movieId = self.ObjRecommendation[indexPath.row].id.description
            self.navigationController?.pushViewController(resultVC, animated: true)
        }
        
        
    }
    
}
