//
//  SearchVC.swift
//  interviewWebcluse
//
//  Created by HOLOTEQ-MAC-PC-3 on 7/20/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import SwiftyJSON

class SearchVC: UIViewController,UISearchResultsUpdating {
    
    @IBOutlet weak var tblSearch: UITableView!
    var displayData : baseFrontpage = baseFrontpage()
    let searchController = UISearchController(searchResultsController: nil)
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.searchController = searchController
        
        navigationItem.hidesSearchBarWhenScrolling = false
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        // Do any additional setup after loading the view.
        
        
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        
        // If the search bar contains text, filter our data with the string
        if let searchText = searchController.searchBar.text {
            
            // if searchText != ""
            // {
            self.displayData.frontpage_list.removeAll()
            getSearch(search: searchText) { (response, err) in
                if let result = response
                {
                    print("success: \(result)")
                    let list = baseFrontpage()
                    list.addItem(data: JSON(result["results"]))
                    print(list.frontpage_list.count)
                    self.displayData.frontpage_list = list.frontpage_list
                    DispatchQueue.main.async {
                        self.tblSearch.reloadData()
                    }
                }else if let error = err
                {
                    print("error: \(error.localizedDescription)")
                }
            }
            //}
            // Reload the table view with the search result data.
            //            tableView2.reloadData()
        }
        
        
        
    }
    //MARK: -  Api method
    func getSearch(search : String,completion: @escaping ([String: Any]?, Error?) -> Void) {
        
        //declare parameter as a dictionary which contains string as key and value combination.
        // let parameters = ["api_key": api_key]
        
        //create the url with NSURL
        
        let url = URL(string:"https://api.themoviedb.org/3/search/movie?api_key=823efcfb80a0302260db02cad43613af&language=en-US&page=1&include_adult=false&query=\(search)")!
        
        //create the session object
        let session = URLSession.shared
        
        //now create the Request object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "GET" //set http method as POST
        
        
        //           do {
        //               request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to data object and set it as request body
        //           } catch let error {
        //               print(error.localizedDescription)
        //               completion(nil, error)
        //           }
        
        //HTTP Headers
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard error == nil else {
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                return
            }
            
            do {
                //create json object from data
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                    completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                    return
                }
                print(json)
                completion(json, nil)
            } catch let error {
                print(error.localizedDescription)
                completion(nil, error)
            }
        })
        
        task.resume()
    }
    
}
extension SearchVC: UITableViewDataSource,UITableViewDelegate
{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as! SearchCell
        cell.selectionStyle = .none
        cell.lblMovieName.text = self.displayData.frontpage_list[indexPath.row].title
        cell.lblRelease.text =  self.displayData.frontpage_list[indexPath.row].release_date
        cell.imgMovie.kf.indicatorType = .activity
        let url = "http://image.tmdb.org/t/p/w185/" + self.displayData.frontpage_list[indexPath.row].poster_path
        
        cell.imgMovie.kf.setImage(with: URL(string: url), placeholder:UIImage(named: "war-b717"))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return displayData.frontpage_list.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let resultVC = Utilities.viewController(name: "DetailVC", onStoryboard: "Authentication") as! DetailVC
        resultVC.movieId = self.displayData.frontpage_list[indexPath.row].id.description
        self.navigationController?.pushViewController(resultVC, animated: true)
    }
}
