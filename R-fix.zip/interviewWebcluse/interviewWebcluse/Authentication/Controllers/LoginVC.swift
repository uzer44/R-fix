//
//  LoginVC.swift
//  BEATEM
//
//  Created by Dipen on 16/01/19.
//  Copyright © 2019 ITCPU020. All rights reserved.
//

import Foundation
import UIKit


class LoginVC : UIViewController
{
    
    //------------------------------------------
    //MARK: - Outlets -
    
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    //------------------------------------------
    //MARK: - Class Variables -
    
    //------------------------------------------
    //MARK: - Memory Management -
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    deinit
    {
        
    }
    
    //------------------------------------------
    //MARK: - Custom Methods -
    
    @objc func setupLayout()
    {
        
    }
    
    //------------------------------------------
    //MARK: - API Methods -
    
    func postRequest(username: String, password: String, requestToken: String,completion: @escaping ([String: Any]?, Error?) -> Void) {
      
        //declare parameter as a dictionary which contains string as key and value combination.
        let parameters = ["username": username, "password": password,"request_token" : requestToken]
        
        //create the url with NSURL
        let url = URL(string: "https://api.themoviedb.org/3/authentication/token/validate_with_login?api_key=823efcfb80a0302260db02cad43613af")!
        
        //create the session object
        let session = URLSession.shared
        
        //now create the Request object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "POST" //set http method as POST
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to data object and set it as request body
        } catch let error {
            print(error.localizedDescription)
            completion(nil, error)
        }
        
        //HTTP Headers
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard error == nil else {
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                return
            }
            
            do {
                //create json object from data
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                    completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                    return
                }
                print(json)
                completion(json, nil)
            } catch let error {
                print(error.localizedDescription)
                completion(nil, error)
            }
        })
        
        task.resume()
    }
    
    //------------------------------------------
    //MARK: - Delegate Methods -
    
    //------------------------------------------
    //MARK: - Action Methods -
    
    @IBAction func btnSigninClicked(_ sender: Any)
    {
        
        if checkValidation()
        {
            postRequest(username: self.txtEmail.text ?? "", password: self.txtPassword.text ?? "", requestToken: UserDefaults.standard.string(forKey: "request_token")!) { (result, error) in
                if let result = result {
                    print("success: \(result)")
                    if  let msg =  result["status_message"]
                    {
                        DispatchQueue.main.async {
                           
                            self.alertpopuo(msg: msg as! String)
                        }
                    }

                    if let success = result["success"]
                    {
                        if success as! Int == 1
                        {
                            UserDefaults.standard.set(true, forKey: "login")
                                                       DispatchQueue.main.async {
                                                           AppInstance.goToHomeScreenPage(transition: true)
                                                           
                                                       }
                        }
                    }
                    
                    
                } else if let error = error {
                    print("error: \(error.localizedDescription)")
                }
                
            }
            
        }
    }
    func alertpopuo(msg: String)
    {
           let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .alert)
           
          
           
           alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                 switch action.style{
                 case .default:
                       print("default")

                 case .cancel:
                       print("cancel")

                 case .destructive:
                       print("destructive")


           }}))
        self.present(alert, animated: true, completion: nil)
    }
    //------------------------------------------
    //MARK: - View Life Cycle Methods -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        self.perform(#selector(setupLayout), with: nil, afterDelay: 0.0)
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
    }
    
    func checkValidation()->Bool
    {
        if (self.txtEmail.text?.isEmpty)!
        {
            Utilities.displayAlert(msg: MSG_EMAIL_EMPTY, isfromlogin: false,navigation:self.navigationController!)
            
            return false
        }
        
        if (self.txtPassword.text?.isEmpty)!
        {
            Utilities.displayAlert(msg: MSG_PASSWORD_EMPTY, isfromlogin: false,navigation:self.navigationController!)
            
            return false
        }
        
        return true
        
    }
    //check mail validation
    func isValidEmail(testStr:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        
        return result
    }
    
    
    //------------------------------------------
}
