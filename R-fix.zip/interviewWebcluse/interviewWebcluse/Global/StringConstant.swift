//
//  StringConstant.swift
//  interviewWebcluse
//
//  Created by Uzer kagdi on 04/07/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import Foundation

var MSG_EMAIL_EMPTY                 = "Please enter email"
var MSG_EMAIL_INVALID               = "Please enter valid email"
var MSG_PASSWORD_EMPTY              = "Please enter password"
var MSG_4YEARS_EMPTY              = "Please enter maximum 4 years of income"
var MSG_YEARS_EMPTY              = "Please enter year & income"
