//
//  EnterDetailVC.swift
//  interviewWebcluse
//
//  Created by Uzer kagdi on 03/07/20.
//  Copyright © 2020 Uzer kagdi. All rights reserved.
//

import UIKit
import CoreData
import SwiftyJSON
class HomeVC: UIViewController {
    
    //------------------------------------------
    //MARK: - Outlets -
    @IBOutlet var tblData: UITableView!
    
    //------------------------------------------
    //MARK: - Class Variables -
    
    var displayData : baseFrontpage = baseFrontpage()
    
    var displayDataToRated : baseFrontpage = baseFrontpage()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblData.reloadData()
        
        self.navigationController?.navigationBar.barTintColor = UIColor.black
    
        //MARK: getPopular Data
             self.getData(_url: "https://api.themoviedb.org/3/movie/popular?api_key=823efcfb80a0302260db02cad43613af&language=en-US&page=1") { (response, err) in
                   if let result = response {
                               print("success: \(result)")
                               let list = baseFrontpage()
                               list.addItem(data: JSON(result["results"]))
                               print(list.frontpage_list.count)
                               self.displayData.frontpage_list = list.frontpage_list
                               
                               
                               //self.displayData.frontpage_list.append(result["results"] as! Frontpage)
                               DispatchQueue.main.async {
                                   self.tblData.reloadData()
                               }
                               
                           } else if let error = err {
                               print("error: \(error.localizedDescription)")
                           }
             }
         //MARK: getToprated Data
        self.getData(_url: "https://api.themoviedb.org/3/movie/top_rated?api_key=823efcfb80a0302260db02cad43613af&language=en-US&page=1") { (response, err) in
                       if let result = response
                                    {
                                        print("success: \(result)")
                                        let list = baseFrontpage()
                                        list.addItem(data: JSON(result["results"]))
                                        print(list.frontpage_list.count)
                                        self.displayDataToRated.frontpage_list = list.frontpage_list
                                        DispatchQueue.main.async {
                                            self.tblData.reloadData()
                                        }
                                    }else if let error = err
                                    {
                                        print("error: \(error.localizedDescription)")
                                    }
                   }
        
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSearchClicked(_ sender: Any)
    {
        let resultVC = Utilities.viewController(name: "SearchVC", onStoryboard: "Authentication") as! SearchVC
        self.navigationController!.pushViewController(resultVC, animated: true)
    }
    
    @IBAction func btnBackClicked(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    //MARK: -  Api method
    
    
    func getData(_url : String,completion: @escaping ([String: Any]?, Error?) -> Void) {
          
          
          
          let url = URL(string:  _url)!
          
          //create the session object
          let session = URLSession.shared
          
          //now create the Request object using the url object
          var request = URLRequest(url: url)
          request.httpMethod = "GET" //set http method as POST
          
          
          //HTTP Headers
          request.addValue("application/json", forHTTPHeaderField: "Content-Type")
          request.addValue("application/json", forHTTPHeaderField: "Accept")
          
          //create dataTask using the session object to send data to the server
          let task = session.dataTask(with: request, completionHandler: { data, response, error in
              
              guard error == nil else {
                  completion(nil, error)
                  return
              }
              
              guard let data = data else {
                  completion(nil, NSError(domain: "dataNilError", code: -100001, userInfo: nil))
                  return
              }
              
              do {
                  //create json object from data
                  guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] else {
                      completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
                      return
                  }
                  print(json)
                  completion(json, nil)
              } catch let error {
                  print(error.localizedDescription)
                  completion(nil, error)
              }
          })
          
          task.resume()
      }
   
}


extension HomeVC : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 2
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : DataCell = tblData.dequeueReusableCell(withIdentifier: "DataCell", for: indexPath) as! DataCell
        if self.displayData.frontpage_list.count > 0 || self.displayDataToRated.frontpage_list.count > 0
        {
            cell.viewcontrollerpush = self
            if indexPath.row == 0
            {
                cell.lblCategory.text = "Popular Movies"
                cell.loadCollectionWithArray(arrayData: self.displayData.frontpage_list)
            }else
            {
                cell.lblCategory.text = "TopRated Movies"
                cell.loadCollectionWithArray(arrayData: self.displayDataToRated.frontpage_list)
            }
            
        }
        
        return cell
    }
    
}
