import Foundation
import SwiftyJSON
class DetailModel {
  
     var title: String?
     var status : String?
    var vote_count : Int?
   var poster_path : String?
    var release_date : String?
    var runtime : Int?
    var homepage : String?
     var _genres = [genres]()
    var backdrop_path : String?
    
   func Populate(dictionary:JSON)
      {
          vote_count = dictionary["vote_count"].intValue
          runtime = dictionary["runtime"].intValue
          title = dictionary["title"].stringValue
        status = dictionary["status"].stringValue
        poster_path = dictionary["poster_path"].stringValue
        release_date = dictionary["release_date"].stringValue
        homepage = dictionary["homepage"].stringValue
      backdrop_path = dictionary["backdrop_path"].stringValue
           
        _genres = genres.PopulateArray(array: dictionary["genres"].arrayValue)
      }
    
    
    
}
class genres
{
    var name : String = ""
    var id : Int = 0
    
    func Populate(dictionary:JSON)
    {
        name = dictionary["name"].stringValue
        id = dictionary["id"].int ?? 0
        
    }
    class func PopulateArray(array:[JSON]) -> [genres]
    {
        var result:[genres] = []
        for item in array
        {
            let newItem = genres()
            newItem.Populate(dictionary: item)
            result.append(newItem)
        }
        return result
    }
   
}
